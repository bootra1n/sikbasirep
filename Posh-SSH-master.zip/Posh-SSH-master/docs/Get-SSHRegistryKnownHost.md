---
external help file: Posh-SSH-help.xml
Module Name: Posh-SSH
online version: https://github.com/darkoperator/Posh-SSH/tree/master/docs
schema: 2.0.0
---

# Get-SSHRegistryKnownHost

## SYNOPSIS
Get KnownHosts from registry (readonly)

## SYNTAX

```
Get-SSHRegistryKnownHost
```

## DESCRIPTION
Get KnownHosts from registry (readonly)
It is windows-only compatibility cmdlet

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
